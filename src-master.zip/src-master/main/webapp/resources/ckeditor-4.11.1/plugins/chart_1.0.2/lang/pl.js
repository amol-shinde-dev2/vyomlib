/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang( 'chart', 'pl', {
	bar: 'Słupkowy',
	chart: 'Wykres',
	chartType: 'Rodzaj wykresu:',
	dialogTitle: 'Edycja Wykresu',
	doughnut: 'Pączek',
	height: 'Wysokość:',
	label: 'Etykieta:',
	line: 'Liniowy',
	pie: 'Ciastko',
	polar: 'Polarny',
	value: 'Wartość:'
} );