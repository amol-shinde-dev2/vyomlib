﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'az', {
	find: 'Tap',
	findOptions: 'Axtarışın seçimləri',
	findWhat: 'Nəyi axtarmaq',
	matchCase: 'Reqistr nəzərə alınmaqla',
	matchCyclic: 'Dövrəvi axtar',
	matchWord: 'Tam sözünə uyğun',
	notFoundMsg: 'Daxil etdiyiniz sorğu ilə heç bir nəticə tapılmayıb',
	replace: 'Əvəz et',
	replaceAll: 'Hamısını əvəz et',
	replaceSuccessMsg: '%1 daxiletmə(lər) əvəz edilib',
	replaceWith: 'Əvəz etdirici mətn:',
	title: 'Tap və əvəz et'
} );
