﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'mk', {
	find: 'Пронајди',
	findOptions: 'Опции за пронаоѓање',
	findWhat: 'Што барате:',
	matchCase: 'Се совпаѓа голема/мала буква,',
	matchCyclic: 'Пребарај циклично',
	matchWord: 'Се совпаѓа цел збор',
	notFoundMsg: 'Внесениот текст не беше пронајден.',
	replace: 'Замени',
	replaceAll: 'Замени ги сите',
	replaceSuccessMsg: '%1 случај/и беа заменети.',
	replaceWith: 'Замени со:',
	title: 'Пронајди и замени'
} );
