﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'find', 'ku', {
	find: 'گەڕان',
	findOptions: 'هەڵبژاردەکانی گەڕان',
	findWhat: 'گەڕان بەدووای:',
	matchCase: 'جیاکردنەوه لەنێوان پیتی گەورەو بچووك',
	matchCyclic: 'گەڕان لەهەموو پەڕەکه',
	matchWord: 'تەنەا هەموو وشەکه',
	notFoundMsg: 'هیچ دەقه گەڕانێك نەدۆزراوه.',
	replace: 'لەبریدانان',
	replaceAll: 'لەبریدانانی هەمووی',
	replaceSuccessMsg: ' پێشهاتە(ی) لەبری دانرا. %1',
	replaceWith: 'لەبریدانان به:',
	title: 'گەڕان و لەبریدانان'
} );
